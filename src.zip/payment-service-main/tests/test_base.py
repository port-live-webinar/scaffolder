from payment_service.base import NAME


def test_base():
    assert NAME == "payment_service"
